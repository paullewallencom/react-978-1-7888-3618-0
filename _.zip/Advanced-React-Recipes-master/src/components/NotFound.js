import React from 'react';

const NotFound = () => (
  <main className="px4 flex">
    <h2 className="h2">404: Dish not found!</h2>
  </main>
);

export default NotFound;
